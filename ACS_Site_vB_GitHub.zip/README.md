
# Advance Construction Services LLC — Website (GitHub Pages)

Este repositorio contiene el sitio estático para **Advance Construction Services LLC**.

## Cómo publicarlo con GitHub Pages (Proyecto)

1. Crea un repositorio nuevo en tu cuenta (por ejemplo: `acs-site`).
2. Sube estos archivos a la rama `main`:
   - `index.html`
   - `assets/style.css`
   - `assets/logo.svg`
3. Ve a **Settings → Pages**.
4. En **Build and deployment**, selecciona:
   - **Source:** Deploy from a branch
   - **Branch:** `main` y **Folder:** `/ (root)`
5. Guarda los cambios. GitHub generará una URL como:
   `https://<TU-USUARIO>.github.io/acs-site/`

> Nota: Si quieres un sitio de usuario (sin `/acs-site/`), el repositorio debe llamarse **`<tu-usuario>.github.io`**. Ese nombre debe coincidir exactamente con tu *usuario de GitHub* (sin acentos ni espacios).

## Edición
- Cambia textos e imágenes en `index.html` y `assets`.
- Los estilos están en `assets/style.css`.

---

Cualquier duda o mejora, contáctame y lo ajustamos.
